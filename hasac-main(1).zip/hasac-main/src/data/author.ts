import avatar from '../assets/images/sample-avatar.jpg';

export const author = {
  name: 'Ağılı EV',
  avatar,
  url: '#',
};

export type Author = typeof author;


